package com.example.mohammedq2finalelec558


import android.animation.TimeAnimator
import android.app.Activity
import android.media.MediaCodec
import android.media.MediaExtractor
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.TextView
import com.example.android.common.media.MediaCodecWrapper
import java.io.IOException


/**
 * This activity uses a [android.view.TextureView] to render the frames of a video decoded using
 * [android.media.MediaCodec] API.
 */
class MainActivity() : Activity() {
    private var mPlaybackView: TextureView? = null
    private val mTimeAnimator: TimeAnimator? = TimeAnimator()

    // A utility that wraps up the underlying input and output buffer processing operations
    // into an east to use API.
    private var mCodecWrapper: MediaCodecWrapper? = null
    private val mExtractor = MediaExtractor()
    var mAttribView: TextView? = null

    /**
     * Called when the activity is first created.
     */
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sample_main)
        mPlaybackView = findViewById<View>(R.id.PlaybackView) as TextureView
        mAttribView = findViewById<View>(R.id.AttribView) as TextView
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.action_menu, menu)
        return true
    }

    override fun onPause() {
        super.onPause()
        if (mTimeAnimator != null && mTimeAnimator.isRunning) {
            mTimeAnimator.end()
        }
        if (mCodecWrapper != null) {
            mCodecWrapper.stopAndRelease()
            mExtractor.release()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.menu_play) {
            mAttribView!!.visibility = View.VISIBLE
            startPlayback()
            item.isEnabled = false
        }
        return true
    }

    fun startPlayback() {

        // Construct a URI that points to the video resource that we want to play
        val videoUri = Uri.parse(
            "android.resource://"
                    + packageName + "/"
                    + R.raw.vid_bigbuckbunny
        )
        try {

            // BEGIN_INCLUDE(initialize_extractor)
            mExtractor.setDataSource(this, videoUri, null)
            val nTracks = mExtractor.trackCount

            // Begin by unselecting all of the tracks in the extractor, so we won't see
            // any tracks that we haven't explicitly selected.
            for (i in 0 until nTracks) {
                mExtractor.unselectTrack(i)
            }


            // Find the first video track in the stream. In a real-world application
            // it's possible that the stream would contain multiple tracks, but this
            // sample assumes that we just want to play the first one.
            for (i in 0 until nTracks) {
                // Try to create a video codec for this track. This call will return null if the
                // track is not a video track, or not a recognized video format. Once it returns
                // a valid MediaCodecWrapper, we can break out of the loop.
                mCodecWrapper = MediaCodecWrapper.fromVideoFormat(
                    mExtractor.getTrackFormat(i),
                    Surface(mPlaybackView!!.surfaceTexture)
                )
                if (mCodecWrapper != null) {
                    mExtractor.selectTrack(i)
                    break
                }
            }
            // END_INCLUDE(initialize_extractor)


            // By using a {@link TimeAnimator}, we can sync our media rendering commands with
            // the system display frame rendering. The animator ticks as the {@link Choreographer}
            // receives VSYNC events.
            mTimeAnimator!!.setTimeListener { animation, totalTime, deltaTime ->
                val isEos =
                    ((mExtractor.sampleFlags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) == MediaCodec.BUFFER_FLAG_END_OF_STREAM)

                // BEGIN_INCLUDE(write_sample)
                if (!isEos) {
                    // Try to submit the sample to the codec and if successful advance the
                    // extractor to the next available sample to read.
                    val result: Boolean = mCodecWrapper.writeSample(
                        mExtractor, false,
                        mExtractor.sampleTime, mExtractor.sampleFlags
                    )
                    if (result) {
                        // Advancing the extractor is a blocking operation and it MUST be
                        // executed outside the main thread in real applications.
                        mExtractor.advance()
                    }
                }
                // END_INCLUDE(write_sample)

                // Examine the sample at the head of the queue to see if its ready to be
                // rendered and is not zero sized End-of-Stream record.
                val out_bufferInfo = MediaCodec.BufferInfo()
                mCodecWrapper.peekSample(out_bufferInfo)

                // BEGIN_INCLUDE(render_sample)
                if (out_bufferInfo.size <= 0 && isEos) {
                    mTimeAnimator.end()
                    mCodecWrapper.stopAndRelease()
                    mExtractor.release()
                } else if (out_bufferInfo.presentationTimeUs / 1000 < totalTime) {
                    // Pop the sample off the queue and send it to {@link Surface}
                    mCodecWrapper.popSample(true)
                }
                // END_INCLUDE(render_sample)
            }

            // We're all set. Kick off the animator to process buffers and render video frames as
            // they become available
            mTimeAnimator.start()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}